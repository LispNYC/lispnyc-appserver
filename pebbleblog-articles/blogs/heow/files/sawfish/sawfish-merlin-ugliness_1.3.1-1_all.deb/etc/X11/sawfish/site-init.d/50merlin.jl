; add placement
(require 'merlin.placement)

; add sawlet-placement
(require 'merlin.sawlet-placement)
(define-sawlet-placement-mode 'south-east-going-north 'south-east 'north)

; add ugliness
(require 'merlin.ugliness)
